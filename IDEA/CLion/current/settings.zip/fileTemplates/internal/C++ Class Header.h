#pragma once
/// copyright ${YEAR} viraltaco_ <https://opensource.org/licenses/MIT>

${NAMESPACES_OPEN}
class ${NAME}  {
public:
	using Self = ${NAME};
	
private: // members

public: // inits

};
${NAMESPACE_CLOSE} // namespace 