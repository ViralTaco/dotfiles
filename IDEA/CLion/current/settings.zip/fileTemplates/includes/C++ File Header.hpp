#pragma once
/// copyright ${YEAR} viraltaco_ <http://www.opensource.org/licenses/MIT>

namespace ${PROJECTNAME} {
class ___FILEBASENAME___ {
protected:
    using self = ___FILEBASENAME___;
    
private: // members

public: // inits
    ___FILEBASENAME___() = default;
};
} // namespace ${PROJECTNAME}
